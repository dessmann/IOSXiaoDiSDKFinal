//
//  xiaodiLib.h
//  xiaodiLib
//
//  Created by 镭 on 16/10/14.
//  Copyright © 2016年 镭. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for xiaodiLib.
FOUNDATION_EXPORT double xiaodiLibVersionNumber;

//! Project version string for xiaodiLib.
FOUNDATION_EXPORT const unsigned char xiaodiLibVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <xiaodiLib/PublicHeader.h>

#import <xiaodiLib/xiaodiSDK.h>

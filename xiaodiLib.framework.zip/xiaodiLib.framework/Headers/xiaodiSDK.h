//
//  xiaodiSDK.h
//  xiaodi～OEM
//
//  Created by 镭 on 16/10/10.
//  Copyright © 2016年 镭. All rights reserved.
//

#import <Foundation/Foundation.h>
@import iOSDFULibrary;

@interface xiaodiSDK : NSObject

/**
 * 返回格式统一说明：
 * 返回：response：｛
 *                  status : 1 成功  0 失败
                    msg：返回话述
                    data：（返回值）
                   ｝
       error：错误信息
 */

//启动蓝牙接口
+(void)startBleService;

//关闭蓝牙服务
+(void)stopBleService;


/**
 * 锁具配对 获取deviceIdentifier
 * 传入json数组：lockseq：锁具mac  scantype：11
 */

+(void)searchBylockseq:(NSString *)lockseq scantype:(NSString *)scantype withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
//停止配对
+(void)stopSearchDevice;
//-------------------------------用户注册登录-------------------------
/**
 * 1.生成验证码
 * 传入json数组：account：账号  type： 1 注册 2 忘记密码
 */
+(void)getAuthCodeRequestWithAccount:(NSString *)account withType:(NSString *)type withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
/**
 * 2.验证码校验
 * 传入json数组：account：账号  type： 1 注册 2 忘记密码 Code：验证码
 * 返回：1 成功
 */
+(void)checkMessageNum:(NSString *)account Type:(NSString *)type Code:code withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
/**
 * 3. 用户注册
 * 传入json数组：account：账号   password：密码
 * 返回： 1 成功 0 失败
 */
+(void)appRegisterWithAccount:(NSString *)account Password:(NSString *)password oemID:(NSString *)oemid withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
/**
 * 4. 用户登录
 * 传入json数组：Account: 账号  Password: 密码
 * 返回： 1 成功 0 失败
 */
+(void)appLoginWithAccount:(NSString *)account PSW:(NSString *)password oemID:(NSString *)oemid withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
/**
 * 5. 修改密码
 * 传入json数组：account：账号   password：密码
 * 返回： 1 成功 0 失败
 */
+(void)updateUserPasswordWithAccount:(NSString *)account Password:(NSString *)password oemID:(NSString *)oemid withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
/**
 * 6.头像上传
 * 传入json数组：Account: 账号  Filename: 文件名
 * 返回： 1 成功 0 失败
 */
+(void)updloadUserPhotoWithAccount:(NSString *)account Filename:(NSString *)filename withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
/**
 * 7. 个人信息完善接口
 * 传入json数组： Useraddress: 地址  Nickname: 昵称 Account: 账号 Cardnum: 身份证号码
 * 返回： 1 成功 0 失败
 */
+(void)updateUserFullInfoWithUseraddress:(NSString *)useraddress Nickname:(NSString *)nickname Account:(NSString *)account Cardnum:(NSString *)cardnum WithName:(NSString *)name withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
/**
 * 8.用户注销
 * 传入json数组：account：账号
 * 返回： 1 成功  0 失败
 */
+(void)logoutWithAccount:(NSString *)account withCompletionHandler:(void (^)(NSString *response, NSString *error))block;

//---------------------------------初始化-----------------------------
/**
 * 1.	获取设备信息： 根据传入的账号（电话号码），返回设备名称  设备mac 地址。
 * 传入json数组：account：账号
 * 返回： 1 成功  0 失败
 */
+(void)showHomePageWithAccount:(NSString *)account withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
//-----------------------------添加设备---------------------
//1.	添加设备
/*
* 传入json数组：
    account：帐号
    nickname:昵称
    locknameString:锁具名称
    lockmacString：锁具mac
    lockIdentifier:设备deviceIdentifier
    deviceType:锁具型号(例如：T700、S800)
    lockLatitude:纬度
    lockLongitude:经度
*/
+ (void)addDeviceWithAccount:(NSString *)account nickname:(NSString *)nickname locknameString:(NSString *)locknameString lockmacString:(NSString *)lockmacString lockIdentifier:(NSString *)lockIdentifier   deviceType:(NSString *)deviceType lockLatitude:(NSString *)lockLatitude lockLongitude:(NSString *)lockLongitude softwareVersion:(NSString *)softwareVersion withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
//-------------------------------手机开门-----------------------------
//1.	确定mac地址的手机开门
/**
 *
 * 传入json数组: Lockseq: 锁具Mac  deviceIdentifier：设备标志 channelPwd：信道密码   Mobile：账号
 *  1 成功   0 失败
 */
+(void)openDoor:(NSString *)lockseq deviceIdentifier:(NSString *)deviceIdentifier channelPwd:(NSString *)channelPwd Mobile:(NSString *)mobile  withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
//---------------------------------个性设置--------------------------------
/**
 * 1.修改锁具名称
 * 传入json数组： lockseq：锁具mac  Newlockname：锁具名称
 * 返回： 1 成功  0 失败
 */
+(void)resetLockName:(NSString *)lockseq Newlockname:(NSString *)newlockname withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
/**
 * 2.修改用户个性化手机开门方式
 * 传入json数组： account：账号 lockseq：锁具mac  OpenType：开门方式(1：摇一摇 2：点一点：3：密码 4：手势)
 * 返回： 1 成功  0 失败
 */
+(void)upUserOpenType:(NSString *)account Lockseq:(NSString *)lockseq OpenType:(NSInteger)opentype withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
/**
 * 3.修改用户个性化开门密码
 * 传入json数组： account：账号 Lockseq：锁具mac Password：密码
 * 返回： 1 成功  0 失败
 */
+(void)upUserOpenPwd:(NSString *)account Lockseq:(NSString *)lockseq Password:(NSString *)password withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
/**
 * 4.修改用户手势密码
 * 传入json数组： account：账号 Lockseq：锁具mac Openpwd：开门密码
 * 返回： 1 成功  0 失败
 */
+(void)upUserHandOpenPwd:(NSString *)account Lockseq:(NSString *)lockseq Openpwd:(NSString *)openpwd withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
/**
 * 5. 手势密码开门校验
 * 传入json数组:  Account: 账号   Lockseq: 锁具Mac  Openpwd：密码
 *  1 成功   0 失败
 */
+(void)checkHandOpenPwd:(NSString *)account Lockmac:(NSString *)lockmac Openpwd:(NSString *)openpwd withCompletionHandler:(void (^)(NSString *response, NSString *error))block;

//------------------------------------高级设置——用户模块--------------------------
//1.	获取当前锁具的用户列表
//传入json数组:  lockseq: 锁具Mac 
+(void)getaccountListBylockseq:(NSString *)lockseq withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
//2.	添加用户
//传入json数组:  lockseq: 锁具Mac  deviceIdentifier：设备标志 manageaccount：管理员账号 username：添加的用户昵称  usermobile：添加的用户手机号
+(void)doSingleUserAddBylockseq:(NSString *)lockseq withDeviceIdentifier:(NSString *)deviceIdentifier withManageaccount:(NSString *)manageaccount withName:(NSString *)username withMobile:(NSString *)usermobile withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
//3.	删除用户
//传入json数组:  lockseq: 锁具Mac  deviceIdentifier：设备标志  mobile：删除的用户手机号 type：删除的用户的用户类型（1是房主 2普通用户）
+(void)doSingleUserDeleteBylockseq:(NSString *)lockseq withDeviceIdentifier:(NSString *)deviceIdentifier withMobile:(NSString *)usermobile withType:(NSString *)type withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
//4.	用户重命名
//传入json数组:account：账号   lockseq: 锁具Mac  newnickname：新昵称
+(void)updateUserLockNickName:(NSString *)account Lockseq:(NSString *)lockseq Newnickname:(NSString *)newnickname withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
//5.	设置用户开门方式
//传入json数组:account：账号   lockseq: 锁具Mac  deviceIdentifier：设备标志  account：账号 opentype：开门方式 isChangeTypeByFingerPrint： NO 指纹指纹开门权限无变更时 YES 有变更
+(void)doUserOpenTypeUpdateBylockseq:(NSString *)lockseq withDeviceIdentifier:(NSString *)deviceIdentifier withAccount:(NSString *)account withOpentype:(NSInteger )opentype  isChangeTypeByFingerPrint:(BOOL )isChangeTypeByFingerPrint withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
//6.	设置时效
+(void)doUserTimePeriodUpdateBylockseq:(NSString *)lockseq withDeviceIdentifier:(NSString *)deviceIdentifier withAccount:(NSString *)currentUserLockAccount withTimePeriod:(NSString *) currentUserLockTimePeriod  withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
//7.	添加指纹
+(void)dosingleFingerInputBylockseq:(NSString *)lockseq withDeviceIdentifier:(NSString *)deviceIdentifier rmobile:(NSString *)rmobile currentUserLockAccount:(NSString *)currentUserLockAccount witnSoftwareVersion:(NSString *)softwareVersion;
//8.	删除指纹
+(void)doSingleFingerDeleteByDeviceIdentifier:(NSString *)deviceIdentifier withFingerID:fingerID fingerlockid:fingerlockid withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
//9.	指纹重命名
//传入json数组:fingerAccount：账号   fingername: 指纹名称 fingerid：指纹id
+(void)updateFingerName:(NSString *)fingerid Fingername:(NSString *)fingername FingerAccount:(NSString *)fingerAccount withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
//10.	获取指纹列表
//传入json数组:fingerAccount：账号   lockseq: 锁具Mac
+(void)getAccountFinger:(NSString *)lockseq FingerAccount:(NSString *)fingerAccount withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
//11.	高级设置验证
+(void)seniorCheckByAccount:(NSString *)account Lockseq:(NSString *)lockseq withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
//12.校验更新锁具时间
+(void)updateLockTime:(NSString *)deviceIdentifier withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
//-----------------------------------------高级设置——开门密码模块---------------------
//1.	设置开门密码（锁具上）
+(void)lockOpenPwdUpdateByLockSeq:(NSString *)lockseq withDeviceIdentifier:(NSString *)deviceIdentifier withPwd:(NSString *)lockOpenPwd withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
//2.	生成临时开门密码
+(void)doGenerateTempSecretKeysByLocseq:(NSString *)lockseq withDeviceIdentifier:(NSString *)deviceIdentifier withAccount:(NSString *)account withsoftwareVersion:(NSString *)softwareVersion withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
//3.	临时钥匙授权
+(void)insertLockTempUserItemWithAccount:(NSString *)account AuthMobile:(NSString *)authMobile Lockmac:(NSString *)lockmac nickName:(NSString *)nickname withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
//4.	临时密码授权
+(void)getDistributeAuthToMate:(NSString *)account Lockseq: (NSString *)lockseq withCompletionHandler:(void (^)(NSString *response, NSString *error))block;


//------------------------------------------高级设置——锁具信息模块----------------------
//1.	获取锁具详情
+(void)getLockMsgByMac:(NSString *)lockmac withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
//2-1	 检测锁具是否有新版本固件
+(void)lockFirewareUpdateCheckBylockseq:(NSString *)lockseq withDeviceIdentifier:(NSString *)deviceIdentifier withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
//2-2   固件下载
+(void)downloadFirmwareFile:(NSString *)url Filename:(NSString *)appName withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
//2-3   固件更新
+(void)Updatelockseq:(NSString *)lockseq withDeviceIdentifier:(NSString *)deviceIdentifier withAppName:(NSString *)appName withAppVersion:(NSString *)appVersion  withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
//2-4   上传固件信息
+(void)updateLockSoftVersion:(NSString *)lockseq Version:(NSString *)version withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
//3.	注销锁具
+(void)doLockLogoutByLocseq:(NSString *)lockseq withDeviceIdentifier:(NSString *)deviceIdentifier withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
//4.	获取wifi
+(void)getCurrentWifiNamewithCompletionHandler:(void (^)(NSString *response, NSString *error))block;
//5.	锁具wifi设置
+(void)doLockWifiUpdateByLocseq:(NSString *)lockseq withDeviceIdentifier:(NSString *)deviceIdentifier withSSID:(NSString *)ssid withPwd:(NSString *)pwd withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
//6.	wifi推送检测
+(void)dolockWifiTestByDeviceIdentifier:(NSString *)deviceIdentifier withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
//7.	开门记录上传功能开启与关闭
+(void)doLockOpenDoorRecordControlBylockseq:(NSString *)lockseq withDeviceIdentifier:(NSString *)deviceIdentifier isUploadOpenDoorRecord:(BOOL )isUploadOpenDoorRecord withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
//8.  WIFI功能开启与关闭  state: 0 关闭 1:开启
+(void)updateLockWIFIState:(NSString *)lockseq withDeviceIdentifier:(NSString *)deviceIdentifier withState:(NSString * )state withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
//---------------------------------------高级设置——亲情模块--------------------------
//1.	设置亲情
+ (void)doinsertLoveAccountRelationItem:(NSString *)lockMac deviceIdentifier:(NSString *)deviceIdentifier account:(NSString *)account accountName:(NSString *)accountName senderAccount:(NSString *)senderAccount senderName:(NSString *)senderName receiverAccount:(NSString *)receiverAccount receiverName:(NSString *)receiverName loveTimeset:(NSString *)loveTimeset withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
//2.	取消亲情设置
+(void)doLoveRelationDeleteByLockSeq:(NSString *)lockseq withDeviceIdentifier:(NSString *)deviceIdentifier withLoverelationID:(NSString *)loverelationID withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
//3.   获取当前设备的所有亲情关联列表
+(void)getLoveAccountRelationByLockSeq:(NSString *)lockseq withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
//-------------------------------------高级设置——报警模块----------------------------
//1.	锁具报警密码设置
+ (void)doAlarmPwdUpdateByLockSeq:(NSString *)lockseq withDeviceIdentifier:(NSString *)deviceIdentifier withAlarmPwd:(NSString *)alarmpwd withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
//2.	锁具报警密码启用关闭
+ (void)doAlarmPwdEnableByLockSeq:(NSString *)lockseq withDeviceIdentifier:(NSString *)deviceIdentifier withStatus:(NSString *)status alarmPassword:(NSString *)alarmPassword  withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
//3.	设置指纹报警关联
+ (void)doFingerAlarmRelationInsertByLockSeq:(NSString *)lockseq Alarmaccount:(NSString *)alarmAccount Alarmaccountname:(NSString *)alarmAccountname Alarmalarmrelation:(NSString *)alarmAlarmrelation  Alarmpassiverelation:(NSString *)alarmPassiverelation Alarmpassiverelationname:(NSString *)alarmPassiverelationname FingerName:(NSString *)fingerName deviceIdentifier:(NSString *)deviceIdentifier withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
//4.	设置密码报警关联
+(void)insertPasswdAlarmAccountRelationItem:(NSString *)alarmLockseq Account:(NSString *)account Accountname:(NSString *)accountname  AlarmAccount:(NSString *)alarmAccount AlarmName:(NSString *)alarmName withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
//5.	取消指纹报警关联
+ (void)doFingerAlarmRelationDeleteByLockSeq:(NSString *)lockseq withDeviceIdentifier:(NSString *)deviceIdentifier withAlarmID:(NSString *)alarmID withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
//6.	取消密码报警关联
+(void)delPwdAlarmRelation:(NSString *)lockseq  AlarmAccount:(NSString *)alarmAccount withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
//7.    查询锁具密码报警关联用户接口
+(void)getPwdAlarmUserList:(NSString *)lockmac withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
//8.    查询锁具指纹报警关联用户接口
+(void)getFingerAlarmUserList:(NSString *)lockmac withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
//---------------------------------------高级设置——记录查询---------------------------
//1.1	App:分页查询锁具开门记录
+(void)getOpenDoorRecordList:(NSString *)lockMac withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
//1.2	App:分页查询亲情记录
+(void)getFamilyDoorRecordList:(NSString *)lockMac withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
//1.3	App:分页查询报警记录
+(void)getLockAlarmList:(NSString *)lockMac withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
//---------------------------智能钥匙---------------------------
//查询设备下的智能钥匙列表
+(void)queryLockSmartkey:(NSString *)lockMac withCompletionHandler:(void (^)(NSString *response, NSString *errorMessage))block;
// 查询智能钥匙的关联信息
+(void)querySmartkeyRelation:(NSString *)keyCode withCompletionHandler:(void (^)(NSString *response, NSString *errorMessage))block;
//扫描智能钥匙
+ (void)scanBleWithCompletionHandler:(void (^)(NSMutableArray *Array, NSString *error))block;
//连接钥匙
+(void)connect:(NSString *)smartKeyName BleArray:(NSMutableArray *)BleArray;
//增加智能钥匙
+(void)addSmartKeyBleArray:(NSMutableArray *)BleArray lockmac:(NSString *)lockmac deviceIdentifier:(NSString *)deviceIdentifier channelpassword:(NSString *)channelpassword Account:(NSString *)account withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
//智能钥匙写入锁具
+(void)addKeyInLock:(NSMutableArray *)BleArray lockmac:(NSString *)lockmac deviceIdentifier:(NSString *)deviceIdentifier dateString:(NSString *)dateString withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
//钥匙重命名
+(void)updateSmartKeyName:(NSString *)lockMac keyCode:(NSString *)keyCode keyPass:(NSString *)keyPass keyName:(NSString *)keyName withCompletionHandler:(void (^)(NSString *response, NSString *errorMessage))block;
//启用智能钥匙
+(void)updateSmartkeyStateOn:(NSString *)lockmac deviceIdentifier:(NSString *)deviceIdentifier keyPass:(NSString *)keyPass keyCode:(NSString *)keyCode withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
//禁用智能钥匙
+(void)updateSmartkeyStateOff:(NSString *)lockmac deviceIdentifier:(NSString *)deviceIdentifier keyPass:(NSString *)keyPass keyCode:(NSString *)keyCode withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
//钥匙删除锁具
+(void)deleteLockFromSmartKey:(NSString *)lockmac deviceIdentifier:(NSString *)deviceIdentifier keyCode:(NSString *)keyCode withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
//锁具删除钥匙
+(void)deleteSmartKeyFromLock:(NSString *)lockmac deviceIdentifier:(NSString *)deviceIdentifier keyCode:keyCode keyPass:(NSString *)keyPass withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
//清空钥匙（测试用）
+(void)removeSmartKeyBleArray:(NSMutableArray *)BleArray withCompletionHandler:(void (^)(NSString *response, NSString *error))block;
@end
